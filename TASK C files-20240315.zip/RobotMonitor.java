public class RobotMonitor
{
   	// constant (ensure you have at least MAX)
   	
	// attributes   
   	
	// invariant
	public boolean inv() 
   	{
            // code here            
   	}
   	
   	// initialisation
   	public RobotMonitor()
   	{
           
   	}
   
   	//operations
   	public int GetCol()
	{
            // code here
	}
	
	public int GetRow()
	{
            // code here
	}
        
        public Move GetMove()
        {
            // DO NOT MODIFY if you are sticking to the simple Robot model
            return null;
        }
	
   	public void MoveRight() 
   	{
            /*
                CHECK precondtion
                IMPLEMENT postcondition
                CHECK invariant 
            */
	}
	
	
	public void MoveLeft() 
   	{
            // code here            
	}
	
	public void MoveDown() 
   	{
            // code here            
	}
	
	public void MoveUp() 
   	{
            // code here            
	}
	
	public void Exit()
   	{
            // code here 
   	}
        
        // toString method added
        public String toString()
        {
            // modify if you are using the text based tester
            return " ";
        }
}